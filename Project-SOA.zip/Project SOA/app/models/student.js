function student(_mssv,_hoten,_ngaysinh,_lop){
  this.mssv = _mssv;
  this.hoten = _hoten;
  this.lop = _lop;
  this.ngaysinh = _ngaysinh;
}

function student_detect(Id,Name,AttdendDate,ImagePath){
  this.Id = Id;
  this.Name = Name;
  this.AttdendDate = AttdendDate;
  this.ImagePath = ImagePath;
}