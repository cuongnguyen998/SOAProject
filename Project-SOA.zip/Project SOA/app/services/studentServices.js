function studentService(){
  this.result = "";


  this.layDanhSachSinhVienDiemDanh = function(){
    $.ajax({
      url: "",
      type: "get",
    })
    .done(function(result){
      this.result = result;
      console.log(this.dsnd);
      var dssv_detect = parseJson(result);
      CreateTable(dssv_detect);
    })
    .fail(function(error){
      console.log(error);
    })
  }
}